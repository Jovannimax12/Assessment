package executetest;

import actionandevents.DataDriving;
import actionandevents.Reporting;
import actionandevents.seleniumDriver;
import actions.swagLabs.swagLabs;
import core.BaseClass;
import extraresources.DataRow;
import org.junit.Rule;
import org.junit.jupiter.api.*;
import org.junit.rules.TestName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ExecuteCode extends BaseClass {

    @Rule
    public static TestName NameOfTest=new TestName();

    @BeforeAll
    public static void init()
    {
        TestName=NameOfTest.getMethodName();
        Reporting.ReportName="Generated Reports";
    }
    @BeforeEach
    public void setUp(TestInfo info)
    {
        seleniumDriverInstance=new seleniumDriver(seleniumDriver.TypeOfBrowser.CHROME);
        Reporting.TestName=info.getDisplayName();
        Reporting.createTest();

    }

   @AfterEach
    public void shutDown()
    {
        seleniumDriverInstance.cleanUp();
    }

    @Test
    public void runswagLabs()
    {
        boolean testswagLabs= swagLabs.runSwagLabs();
        assertTrue(testswagLabs==true,String.valueOf(testswagLabs));
    }



}
