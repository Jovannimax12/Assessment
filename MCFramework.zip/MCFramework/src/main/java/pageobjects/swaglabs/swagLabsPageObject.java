package pageobjects.swaglabs;

import org.openqa.selenium.By;

public class swagLabsPageObject {

    public static String swagPageURL()
    {
        return "http://www.way2automation.com/angularjs-protractor/webtables/";
    }

    public static String Username()
    {
        return "//input[@id='user-name']";
    }

    public static String password()
    {
        return "//input[@id='password']";
    }

    public static String homepageValidation()
    {
        return "//div[@class='login_logo']";
    }

    public static String addButton() { return ("//td//button[@class='btn btn-link pull-right']"); }

    public static String loginButton()
    {
        return "//input[@type='submit' and @value='LOGIN']";
    }

    public static String closeMenu(){return "//span[@class='bm-burger-bars']/..";}

    public static String logOutButton()
    {
        return ("//a[@id='logout_sidebar_link']");
    }
    public static String homePage(){return "//div[@class='app_logo']";}

            //"//div[@class='header_label' and contains(text(),'Swag Labs')]";}
}
