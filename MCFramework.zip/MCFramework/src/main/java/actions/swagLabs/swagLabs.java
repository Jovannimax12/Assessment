package actions.swagLabs;


import core.BaseClass;
import org.openqa.selenium.By;
import pageobjects.swaglabs.swagLabsPageObject;

public class swagLabs extends BaseClass{
    private static boolean statusChecker=true;
    public swagLabs()
    {

    }
    public static boolean runSwagLabs()
    {
        if(!seleniumDriverInstance.openWebPageWithUrl(swagLabsPageObject.swagPageURL()))
        {
            statusChecker=false;
        }

        if(!seleniumDriverInstance.waitForElement(By.xpath(swagLabsPageObject.homepageValidation())))
        {
            statusChecker=false;
        }
        else
        {
            seleniumDriverInstance.pausePerSeconds(1000);
        }
        if(!seleniumDriverInstance.enterText(By.xpath(swagLabsPageObject.Username()),"problem_user"))
        {
            statusChecker=false;
        }

        if(!seleniumDriverInstance.enterText(By.xpath(swagLabsPageObject.password()),"secret_sauce"))
        {
            statusChecker=false;
        }


        if(!seleniumDriverInstance.clickElement(By.xpath(swagLabsPageObject.loginButton())))
        {
            statusChecker=false;
        }
        //seleniumDriverInstance.pausePerSeconds(31000);

    /*    if(!seleniumDriverInstance.clickElement(By.xpath(swagLabsPageObject.closeMenu())))
        {
            statusChecker=false;
        }*/
        if(!seleniumDriverInstance.waitForElement(By.xpath(swagLabsPageObject.homePage())))
        {
            statusChecker=false;
        }else{
            getPageState();
            System.out.println("Completed running : STOPPED");
        }


        return statusChecker;
    }

    private static void getPageState()
    {
         int x=0;
        while(x<10)
        {

            if(x<10){

                statusChecker=true;
                if(statusChecker==true)
                {
                    System.out.println("Still running...");
                }
            }else
            {
                statusChecker=false;
            }
            seleniumDriverInstance.pausePerSeconds(10000);
            x++;
        }
    }
}
