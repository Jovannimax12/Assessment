package extraresources;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class DataRow {
    public List<DataColumn> columns;
    public DataRow()
    {
        columns=new ArrayList<DataColumn>();
    }

    public String getColumnValue(String columnHeader)
    {
        try{
            Predicate<DataColumn> predicate= c-> c.key.equals(columnHeader);
            DataColumn obj=columns.stream().filter(predicate).findFirst().get();
            return obj.value;
        }catch (Exception ex){
            System.out.println("[ERROR] Could not find column - "+columnHeader+" - in table row");
            return "";
        }
    }
}
