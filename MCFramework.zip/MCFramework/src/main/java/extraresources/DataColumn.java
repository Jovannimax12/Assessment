package extraresources;

public class DataColumn extends DataRow {
    public String key;
    public String value;

    public DataColumn(String key,String value)
    {
        this.key=key;
        this.value=value;
    }
}
