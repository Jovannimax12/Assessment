package core;
import actionandevents.AppiumUtility;
import actionandevents.seleniumDriver;

public class BaseClass
{
    public static String reportDirectory=System.getProperty("user.dir")+"\\Reports\\";
    public static seleniumDriver seleniumDriverInstance;
    public static AppiumUtility appiumInstance;
    public static String TestName;
}
