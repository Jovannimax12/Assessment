package actionandevents;

//import gtc.keyworddriventestingframework.reporting.Narrator;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.sql.Driver;

public class AppiumUtility
{
    private AndroidDriver androidDriver;
    private AppiumDriverLocalService appiumService;
    private static int screenShotCounter;

    public void startService()
    {
        appiumService=AppiumDriverLocalService.buildDefaultService();
        appiumService.start();
    }

    public void launchApp(DesiredCapabilities desiredCapabilities)
    {

    }

    public void startDriver(DesiredCapabilities caps)
    {
        try {
            this.androidDriver=new AndroidDriver(appiumService,caps);
        }catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }

    }
    public static DesiredCapabilities setRunCapabilities(String DeviceName,String platformVersion,String platformName,String appPackage,String appActivity,String appFilePath)
    {
        DesiredCapabilities caps=new DesiredCapabilities();
        caps.setCapability("deviceName",DeviceName);
        caps.setCapability("automationName","uiautomator2");
        caps.setCapability("platformVersion",platformVersion);
        caps.setCapability("platformName",platformName);
        caps.setCapability("appPackage",appPackage);
        caps.setCapability("appActivity",appActivity);
        caps.setCapability("fullReset","false");
        caps.setCapability("app",appFilePath);
        caps.setCapability("sendKeyStrategy","grouped");
        return caps;
    }

    public static DesiredCapabilities setRunCapabilities2(String[] capability)
    {
        DesiredCapabilities caps=new DesiredCapabilities();
        String[] capabilityName={"deviceName","automationName","platformVersion","platformName","appPackage","appActivity","fullReset","app","sendKeyStrategy"};
        for(int x=0;x<capability.length;x++)
        {
            caps.setCapability(capabilityName[x],capability[x]);
        }
        return caps;
    }

    public boolean cleanUp()
    {
        try {
            this.androidDriver.closeApp();
            this.androidDriver.close();
            this.appiumService.stop();
            return true;
        }catch (Exception ex)
        {
            return false;
        }
    }

    public boolean waitForElement(By elementPath)
    {
        try
        {
            WebDriverWait wait=new WebDriverWait(androidDriver,5);//made change
            wait.until(ExpectedConditions.presenceOfElementLocated(elementPath));
            return true;
        }catch (Exception ex){
            return false;
        }

    }
    public boolean clickElement(By elementPath)
    {
        try
        {
            waitForElement(elementPath);
            WebDriverWait wait=new WebDriverWait(androidDriver,3);//made change
            wait.until(ExpectedConditions.elementToBeClickable(elementPath));
            WebElement element=this.androidDriver.findElement(elementPath);
            element.click();
          //  Reporting.logPass("Clicked Element : "+ elementPath);
            return true;
        }catch (Exception ex)
        {
          //  Reporting.logError("Failed to click Element : "+ex.getMessage());
            return false;
        }
    }

    public boolean enterText(By elementPath,String text)
    {
        try {
            waitForElement(elementPath);
            WebElement element = this.androidDriver.findElement(elementPath);
            element.sendKeys(text);
         //   Reporting.logPass("Entered text to : "+ elementPath);
            return true;
        }catch (Exception ex){
         //   Reporting.logError("Failed to enter text : "+ex.getMessage());
            return false;}
    }


    public boolean validateText(By elementPath,String textToValidate)
    {
        try {
            waitForElement(elementPath);
            WebElement element = this.androidDriver.findElement(elementPath);
            element.sendKeys(textToValidate);
            Reporting.logPass("Validated text in "+ elementPath);
            return true;
        }catch (Exception ex)
        {
            Reporting.logError("Failed to validate : "+ex.getMessage());
            return false;}
    }

/*    public String createScreenShot(boolean status)
    {
        screenShotCounter++;
        StringBuilder imagePathBuilder=new StringBuilder();
        StringBuilder relativePathBuilder=new StringBuilder();
        try
        {
//            imagePathBuilder.append(reportDirectory);
            relativePathBuilder.append("Screenshots\\");
            new File(imagePathBuilder.toString()+(relativePathBuilder).toString()).mkdirs();
            relativePathBuilder.append(screenShotCounter+"_");
            if(status){
                relativePathBuilder.append("PASSED");
            }else{
                relativePathBuilder.append("FAILED");
            }
            relativePathBuilder.append(".png");
            File screenshot=((TakesScreenshot)getWebdriver()).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot,new File(imagePathBuilder.append(relativePathBuilder).toString()));
            Reporting.logPass("Screenshot has been taken : "+screenShotCounter+"_"+status+".png");
            return "./"+relativePathBuilder.toString();
        }catch(Exception ex)
        {
            Reporting.logError("Failed to take Screenshot : "+ex.getMessage());
            return null;
        }
    }*/
    public boolean switchToTabOrWindow() {
        try {
            String winHandleAfter = "";
            for (String winHandle : androidDriver.getWindowHandles()) {
                winHandleAfter = winHandle;
                androidDriver.switchTo().window(winHandle);
            }
            //Validate switch.
            if (!winHandleAfter.equalsIgnoreCase(androidDriver.getWindowHandle())) {
               // Narrator.logError("Failed to switch to new tab" + winHandleAfter);
                return false;
            }
        } catch (Exception ex) {
           // Narrator.logError("Could not switch to new tab" + ex.getMessage());
            return false;
        }
        //Narrator.logDebug("Switched to window " + androidDriver.getTitle());
        return true;
    }

}
