package actionandevents;
import com.aventstack.extentreports.AnalysisStrategy;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import core.BaseClass;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Reporting extends BaseClass
{
    public  static ExtentReports report;
    public static ExtentTest currentTest;
    public static String ReportName;
    public static String TestName;
    public static String narratorLog;


    public  static void setup()
    {
        report=new ExtentReports();
        reportDirectory=reportDirectory+TestName+"\\"+currentTime()+"\\";
        new File(reportDirectory).mkdirs();
        narratorLog=reportDirectory+"Narratorlog.txt";
        ExtentHtmlReporter htmlReporter=new ExtentHtmlReporter(reportDirectory+"ExtentReport.html");
        report.attachReporter(htmlReporter);
        report.setAnalysisStrategy(AnalysisStrategy.TEST);
        report.flush();

    }

    private static String currentTime()
    {

        SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh-mm-ss");
        return dateFormat.format(new Date());
    }
    public static void createTest()
    {
        if(report==null)
        { setup();}
        if(currentTest==null || !currentTest.getModel().getName().equals(TestName))
        {currentTest=report.createTest(TestName);}
    }

    public static String stepPassed(String message)
    {
        if(currentTest==null)
        {createTest();}
        try {
            currentTest.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(seleniumDriverInstance.createScreenShot(true)).build());
        } catch (IOException e) {
            e.printStackTrace();
        }
        report.flush();
        return null;
    }

    public static String stepPassedWithScreenShot(String message)
    {
        try {
            if(currentTest==null)
            {createTest();}
            currentTest.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(seleniumDriverInstance.createScreenShot(true)).build());
        } catch (Exception e) {
            e.printStackTrace();
        }
        report.flush();
        return null;
    }
    public static String testFailed(String message)
    {
        if(currentTest==null)
        {createTest();}
        try {
            currentTest.fail(message, MediaEntityBuilder.createScreenCaptureFromPath(seleniumDriverInstance.createScreenShot(true)).build());
        } catch (IOException e) {
            e.printStackTrace();
        }
        report.flush();
        return message;
    }
    public static void warning(String message)
    {
        report.flush();
        currentTest.warning(message);
    }

    public static void info(String message) {
        report.flush();
        currentTest.info(message);
    }
    public static void logError(String error) {

        try {
            writeToLogFile("- [EROR] : " + error);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void logDebug(String debug) {
        try {
            writeToLogFile("- [DBUG] : " + debug);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void logPass(String pass) {
        try {
            writeToLogFile("- [PASS] : " + pass);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void logFailure(String failure) {
        try {
            writeToLogFile("- [FAIL] : " + failure);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void logFailure(String failure, String testName) {
        try {
            writeToLogFile("- [FAIL] Test - "+testName+" : " + failure);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static void logInfo(String info) {
        try {
            writeToLogFile("- [INFO] : " + info);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

/*    public static void logStatus()
    {
        try {
            writeToLogFile("- [INFO] : " + info);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
*/
    private static void writeToLogFile(String logMessage) throws IOException {

        File file = new File(narratorLog);
        String formatStr = "%n%-24s %-20s %-60s %-25s";
        if (!file.exists()) {
            file.createNewFile();
            PrintWriter writer = new PrintWriter(new FileWriter(file, true));
            writer.println(String.format(formatStr, "", "-- NARRATOR LOG FILE --", "", ""));
            writer.close();
        }
        //Writes info to the text file
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(file, true));
            writer.println(String.format(formatStr, new SimpleDateFormat("yyyy-MM-dd hh-mm-ss").format(new Date()), logMessage, "", ""));
            writer.close();
        } catch (IOException e) {
            System.out.printf(e.getMessage());
        }
    }


}
