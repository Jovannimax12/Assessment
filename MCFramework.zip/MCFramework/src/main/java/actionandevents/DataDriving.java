package actionandevents;

import core.BaseClass;
import extraresources.DataColumn;
import extraresources.DataRow;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataDriving extends BaseClass
{
 public static XSSFWorkbook getWorkbook(String filePath)
 {
     try {
         FileInputStream excelFile=new FileInputStream(new File(filePath));
         XSSFWorkbook workbooks=new XSSFWorkbook(excelFile);
         return workbooks;
     } catch (FileNotFoundException e) {
         e.printStackTrace();
     } catch (IOException e) {
         e.printStackTrace();
     }
     return null;
 }
    public static Sheet getWorkSheet(XSSFWorkbook workbook, String sheetname)
    {
        Sheet sheet= (Sheet) workbook.getSheet(sheetname);
        return sheet;
    }
    public static XSSFSheet getWorkSheets(String filepath, String sheetname)
    {
        try {
            XSSFWorkbook workbook = getWorkbook(filepath);
            XSSFSheet sheet = workbook.getSheet(sheetname);
            return sheet;
        }catch (Exception ex)
        {
            return null;
        }

    }

    public static List<DataRow> getSheetAsTable(String filePath, String sheetname)
    {
        List<DataRow> table=new ArrayList<>();
        XSSFSheet sheet =getWorkSheets(filePath,sheetname);
        int lastRow=sheet.getLastRowNum();
        Row colRow=sheet.getRow(0);
        for(int x=1;x<=lastRow;x++)
        {

            DataRow dataRow=new DataRow();
            Row row=sheet.getRow(x);
            int lastCell=row.getLastCellNum();
            for(int y=0;y<lastCell;y++)
            {
                Cell cell=row.getCell(y);
                DataColumn dataColumn=new DataColumn(colRow.getCell(y).getStringCellValue(),cell.getStringCellValue());
                dataRow.columns.add(dataColumn);
            }
            table.add(dataRow);
        }

        return table;
    }
}
