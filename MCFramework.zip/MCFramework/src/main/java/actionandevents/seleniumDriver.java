package actionandevents;

import core.BaseClass;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;


public class seleniumDriver extends BaseClass
{

    private static WebDriver webdriver;
    private static TypeOfBrowser selectedBrowser;
    private static int screenShotCounter=0;
    public seleniumDriver(TypeOfBrowser selectedBrowser)
    {
        this.selectedBrowser=selectedBrowser;
        instantiateDriver();
        this.webdriver.manage().window().maximize();
    }

    public seleniumDriver() {
    }


    public enum TypeOfBrowser
    {
        CHROME,IE,FIREFOX;
    }

    public TypeOfBrowser getSelectedBrowser()
    {
        return this.selectedBrowser;
    }

    public WebDriver getWebdriver()
    {
        return this.webdriver;
    }

    public void instantiateDriver()
    {
        switch (this.selectedBrowser)
        {
            case CHROME :
                WebDriverManager.chromedriver().setup();
                this.webdriver=new ChromeDriver();
                break;
        }
    }

    public boolean openWebPageWithUrl(String url)
    {
        try {
            this.webdriver.navigate().to(url);
            return true;
        }catch (Exception ex)
        {return false;}
    }

    public static boolean cleanUp()
    {
        try {
            webdriver.close();//made change
            webdriver.quit();
            return true;
        }catch (Exception ex)
        {
            return false;
        }
    }



    public boolean waitForElement(By elementPath)
    {
        try
        {
            WebDriverWait wait=new WebDriverWait(webdriver,5);//made change
            wait.until(ExpectedConditions.presenceOfElementLocated(elementPath));
            return true;
        }catch (Exception ex){
            return false;
        }

    }


    public boolean clickElement(By elementPath)
    {
      try
      {
          waitForElement(elementPath);
          WebDriverWait wait=new WebDriverWait(webdriver,100);//made change
          wait.until(ExpectedConditions.elementToBeClickable(elementPath));
          WebElement element=this.webdriver.findElement(elementPath);
          element.click();
          Reporting.logPass("Clicked Element : "+ elementPath);
          return true;
      }catch (Exception ex)
      {
          Reporting.logError("Failed to click Element : "+ex.getMessage());
          return false;
      }
    }


 /*   public Boolean setCheckBox(By elementPath, Boolean check) {
        try {
            waitForElement(elementPath);
            WebDriverWait wait = new WebDriverWait(webdriver, 100);
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));

            if (!element.isSelected() && check) {
                element.click();
                return true;
            } else if (element.isSelected() && !check) {
                element.click();
                return true;
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }*/

    public boolean enterText(By elementPath,String text)
    {
        try {
            waitForElement(elementPath);
            WebElement element = this.webdriver.findElement(elementPath);
            element.sendKeys(text);
            Reporting.logPass("Entered text to : "+ elementPath);
            return true;
        }catch (Exception ex){
            Reporting.logError("Failed to enter text : "+ex.getMessage());
        return false;}
    }


    public boolean validateText(By elementPath,String textToValidate)
    {
        try {
            waitForElement(elementPath);
            WebElement element = this.webdriver.findElement(elementPath);
            element.sendKeys(textToValidate);
            Reporting.logPass("Validated text in "+ elementPath);
            return true;
        }catch (Exception ex)
        {
            Reporting.logError("Failed to validate : "+ex.getMessage());
            return false;}
    }



/*    public static boolean scrollToElement(By elementPath) {
        try {
            WebElement element = Driver.findElement(By.xpath(elementXpath));
            ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", element);
            Narrator.logDebug("Scrolled to element - " + elementXpath);
            return true;
        } catch (Exception e) {
            Narrator.logError("Error scrolling to element - " + elementXpath + " - " + Arrays.toString(e.getStackTrace()));

            return false;
        }

    }*/





 /*   public static Boolean setRadioButton(String xpath) {
        try {
            waitForElement(xpath);
            WebDriverWait wait = new WebDriverWait(Driver, 1);
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));

            if (!element.isSelected()) {
                element.click();
                return true;
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }*/


    public static void pausePerSeconds(int sec)
    {
        try {
            Thread.sleep(sec);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public String createScreenShot(boolean status)
    {
        screenShotCounter++;
        StringBuilder imagePathBuilder=new StringBuilder();
        StringBuilder relativePathBuilder=new StringBuilder();
        try
        {
            imagePathBuilder.append(reportDirectory);
            relativePathBuilder.append("Screenshots\\");
            new File(imagePathBuilder.toString()+(relativePathBuilder).toString()).mkdirs();
            relativePathBuilder.append(screenShotCounter+"_");
            if(status){
                relativePathBuilder.append("PASSED");
            }else{
                relativePathBuilder.append("FAILED");
            }
            relativePathBuilder.append(".png");
            File screenshot=((TakesScreenshot)getWebdriver()).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshot,new File(imagePathBuilder.append(relativePathBuilder).toString()));
            Reporting.logPass("Screenshot has been taken : "+screenShotCounter+"_"+status+".png");
            return "./"+relativePathBuilder.toString();
        }catch(Exception ex)
        {
            Reporting.logError("Failed to take Screenshot : "+ex.getMessage());
            return null;
        }
    }
}
